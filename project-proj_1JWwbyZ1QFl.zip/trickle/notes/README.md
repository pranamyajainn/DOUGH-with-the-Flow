# DOUGH with the Flow Café - Landing Page

## Project Overview
A modern, cozy, and aesthetic landing page for "DOUGH with the Flow Café" - a pure vegetarian donut café featuring warm vintage vibes with pastel tones.

## Design Theme
- **Color Palette**: Cream (#FAF7F2), Blush Pink (#E8B4B8), Muted Olive (#A8B5A0), Soft Browns (#6B4E3D, #9C8C7C)
- **Typography**: Inter for body text, Playfair Display for headings
- **Style**: Cozy, vintage-inspired, artisan aesthetic

## Features
- Responsive landing page with sticky navigation
- Hero section with compelling messaging and imagery
- About section highlighting café values and story
- Menu showcase with donut varieties and pricing
- Location and contact information
- Footer with social links and quick navigation

## Sections
1. **Header**: Navigation with café branding and menu links
2. **Hero**: Main welcome with call-to-action and social proof
3. **About**: Café story, values (Pure Vegetarian, Made with Love, Cozy Atmosphere)
4. **Menu**: Featured donuts and beverage pairings
5. **Location**: Contact details, hours, and special events
6. **Footer**: Complete café information and social media links

## Technical Stack
- React 18 with vanilla HTML/CSS/JS
- TailwindCSS for styling with custom CSS variables
- Lucide icons for UI elements
- Responsive design for all device sizes

## Assets Used
- High-quality Unsplash images for donuts, café interior, and coffee
- All images selected to match the cozy, artisan aesthetic