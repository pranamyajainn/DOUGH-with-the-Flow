When project updates are made to DOUGH with the Flow Café website
- Always check if the README.md in trickle/notes needs updates
- Update project overview if new features are added
- Update design theme information if colors or typography changes
- Update sections list if new components are added or removed
- Update technical stack information if new libraries or frameworks are integrated
- Update assets used section when new images or resources are added